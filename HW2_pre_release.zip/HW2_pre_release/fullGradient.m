function [dWi,dWo] = fullGradient(Wi,Wo,alpha_i,alpha_o, Inputs, Labels, nclasses)
%
% Calculate the partial derivatives of the quadratic cost function
% wrt. the weights. Derivatives of quadratic weight decay are included.
%
% Input:
%        Wi      :  Matrix with input-to-hidden weights
%        Wo      :  Matrix with hidden-to-outputs weights
%        alpha_i :  Weight decay parameter for input weights
%        alpha_o :  Weight decay parameter for output weights
%        Inputs  :  Matrix with examples as rows
%        Targets :  Matrix with target values as rows
% Output:
%        dWi     :  Matrix with gradient for input weights
%        dWo     :  Matrix with gradient for output weights

% Determine the number of examples

    function [y] = softmax(z)
    % Paste your softmax function here
    
    end
    
    function [y] = relu(x)
    % Paste your relu function here
    
    end
    
    function [d] = onehotenc(nclasses, k)
    % Paste your one hot encoder here
    
    end

[ndata, inp_dim] = size(Inputs);

dWi = zeros(size(Wi));
dWo = zeros(size(Wo));

% compute the derivatives for each data point separately.
for k=1:ndata
  %%%%%%%%%%%%%%%%%%%%
  %%% FORWARD PASS %%%
  %%%%%%%%%%%%%%%%%%%%
  %
  % Propagate kth example forward through network
  % calculating all hidden- and output unit outputs
  %
  
  % Calculate hidden unit outputs for every example
  

  
  %%%%%%%%%%%%%%%%%%%%%
  %%% BACKWARD PASS %%%
  %%%%%%%%%%%%%%%%%%%%%
  % Back propagation
  % Calculate derivative of
  % by backpropagating the errors from the
  % desired outputs
  

end


% Add derivatives of the weight decay term

end



