function [ D_im] = plotDict2D(D,nib,dims)
% [D_im] = plotDict2D(D,nib)
% function to make 2D dictionary image
% D = dictionary
% nib = number of pixes per block side (square)
% D_im = 2D dictionary image (sorted by variance, contrast normalized)
% mjb 5/22/17

if nargin < 3
dims = ceil(sqrt(size(D,2)));
end

D_im = zeros(dims*(nib)+dims+1); % dims+1 is border
count00 = 0;
% [~,ii]=sort(std(D));%'descend');
% Dprint = D(:,ii);
Dprint = D;
for m = 1:dims
    for n = 1:dims
        if count00 < size(D,2)
            count00 = count00+1;
            Dim0 = reshape(Dprint(:,count00),[nib,nib]);
%             Dim0 = Dim0-min(Dim0); % contrast normalization
%             Dim0 = Dim0./max(Dim0);
% %             Qim((m-1)*bb+1:m*bb,(n-1)*bb+1:n*bb)= Qim0;
            D_im((m-1)*nib+1+m:m*nib+m,(n-1)*nib+1+n:n*nib+n)= Dim0;
        else
            continue
        end
    end
    if count00 >= size(D,2)
        continue
    end
end


end

