function [a, b] = softsvm(X, t, C)
  

end