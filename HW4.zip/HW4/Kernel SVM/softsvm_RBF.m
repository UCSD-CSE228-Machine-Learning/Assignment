function [a, b] = softsvm_RBF(X, t, C)
  

end